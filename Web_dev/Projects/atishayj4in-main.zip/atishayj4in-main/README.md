![logo](Picsart_24-09-23_19-44-14-675.jpg)
<h1 align="center">Hi 👋🏻, I'm ΛƬIƧHΛY JΛIИ</h1>
<h3 align="center">A Data Science Student and AI-ML-DL Enthusiast from India</h3>
<img align = "right" alt = "coding" width = "185" src = "https://camo.githubusercontent.com/88adc7c88c9d3dba7479020846ed35d13410e3707c7f149e1c6140cc6beaef9a/68747470733a2f2f70687973696373677572756b756c2e66696c65732e776f726470726573732e636f6d2f323031392f30322f6368617261637465722d312e676966"> 
<img align = "right" alt = "coding" width = "185" src = "https://camo.githubusercontent.com/5046cb083418fd1922b7f5990e594c3bb06f5d87e5516cd8839ae0aa48b3aec4/68747470733a2f2f696d616765732e73717561726573706163652d63646e2e636f6d2f636f6e74656e742f76312f3537363966633430316236333162616231616464623261622f313534313538303631313632342d5445363451474b524a4738535741495553374e532f6b6531375a77644742546f6464493870446d34386b506f73776c7a6a53564d4d2d53784f703743563539425a772d7a505067646e346a557756634a45315a7657515578776b6d794578676c4e714770304976544a5a616d574c49327a76595748384b332d735f3479737a63703272795449304871544f6161556f68724938504936465879386339505774426c7141566c555335697a7064634958445a71445976707252715a32395077306f2f636f64696e672d667265616b2e676966">


<p align="left"> <img src="https://komarev.com/ghpvc/?username=atishayj4in&label=Profile%20views&color=0e75b6&style=flat" alt="atishayj4in" /> </p>

- 🌱 I’m currently learning **Machine Learning and Deep Learning**

- 📫 How to reach me **atishayj4in@gmail.com**

</br>
<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://twitter.com/atishayj4in" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="atishayj4in" height="30" width="40" /></a>
<a href="https://linkedin.com/in/atishayj4in" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="atishayj4in" height="30" width="40" /></a>
<a href="https://instagram.com/atishayj4in" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="atishayj4in" height="30" width="40" /></a>
<a href="https://www.leetcode.com/atishayj4in" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/leet-code.svg" alt="atishayj4in" height="30" width="40" /></a>
</p>
</br>
<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://www.cprogramming.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> </a> <a href="https://www.w3schools.com/cpp/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> </a> <a href="https://git-scm.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a> <a href="https://www.java.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> </a> <a href="https://www.mathworks.com/" target="_blank" rel="noreferrer"> <img src="https://upload.wikimedia.org/wikipedia/commons/2/21/Matlab_Logo.png" alt="matlab" width="40" height="40"/> </a> <a href="https://www.mongodb.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="40"/> </a> <a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a> <a href="https://opencv.org/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/opencv/opencv-icon.svg" alt="opencv" width="40" height="40"/> </a> <a href="https://pandas.pydata.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/2ae2a900d2f041da66e950e4d48052658d850630/icons/pandas/pandas-original.svg" alt="pandas" width="40" height="40"/> </a> <a href="https://www.postgresql.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/postgresql/postgresql-original-wordmark.svg" alt="postgresql" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://pytorch.org/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/pytorch/pytorch-icon.svg" alt="pytorch" width="40" height="40"/> </a> <a href="https://scikit-learn.org/" target="_blank" rel="noreferrer"> <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Scikit_learn_logo_small.svg" alt="scikit_learn" width="40" height="40"/> </a> <a href="https://seaborn.pydata.org/" target="_blank" rel="noreferrer"> <img src="https://seaborn.pydata.org/_images/logo-mark-lightbg.svg" alt="seaborn" width="40" height="40"/> </a> <a href="https://www.tensorflow.org" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/tensorflow/tensorflow-icon.svg" alt="tensorflow" width="40" height="40"/> </a> </p>
<br>
<h3 align="left">Recent Projects:</h3>
<p align="left">
<a href="https://github.com/atishayj4in/Dog_and_Cat_Classifier" target="blank"><img align="center" src="github_images/Dog_and_Cat_Classifier.jpg" alt="atishayj4in" height="170" width="170" /></a>
<a href="https://github.com/atishayj4in/Chess_Game" target="blank"><img align="center" src="github_images/python_chess_game.jpg" alt="atishayj4in" height="170" width="170" /></a>
<a href="https://github.com/atishayj4in/Handwritten_Digits_Classifier" target="blank"><img align="center" src="github_images/Handwritten_Digits_Image_Cla.jpg" alt="atishayj4in" height="170" width="170" /></a>
<a href="https://github.com/atishayj4in/Multilingual_Audio_Classifier" target="blank"><img align="center" src="github_images/Multilingual_Audio_Classifier.jpg" alt="atishayj4in" height="170" width="170" /></a>
</p>
<br>
<h3 align="left">Updated Resume:</h3>
<p align="left">
<a href="https://drive.google.com/drive/folders/1kAWrmdHYvDM4SiY7IGESBDzQwf1ad1DY" target="blank"><img align="center" src="github_images/resume_image.png" alt="atishayj4in" height="100" width="71" /></a>
<div>Click☝for My Updated Resume</div>
</p>
<br>
<h3 align="left">Github Stats:</h3>
<p align="left">
<p><img align="center" src="https://github-readme-stats.vercel.app/api/top-langs?username=atishayj4in&show_icons=true&locale=en&layout=compact" alt="atishayj4in" /></p>
<br>
<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=atishayj4in&show_icons=true&locale=en" alt="atishayj4in" /></p>
<br>
<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=atishayj4in&" alt="atishayj4in" /></p>
