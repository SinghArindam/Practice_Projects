/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['www.apple.com',
        'store.storeimages.cdn-apple.com',
        'image.tmdb.org','https://image.tmdb.org' ,'apple.com','https://i.ytimg.com','https://istyle.cz'],
      },
      
};

export default nextConfig;
