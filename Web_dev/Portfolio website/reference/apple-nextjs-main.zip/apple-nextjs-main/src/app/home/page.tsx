// /app/home/page.tsx or /pages/home.tsx
import React from "react";

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to the Home Page</h1>
      <p>This content should display in the browser.</p>
    </div>
  );
};

export default HomePage;
