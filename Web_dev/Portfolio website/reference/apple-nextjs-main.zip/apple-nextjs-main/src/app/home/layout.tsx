import React from "react";
import DiscountBar from "../components/Discountbar/DiscountBar";

function layout() {
  return (
    <div>
      <DiscountBar />
    </div>
  );
}

export default layout;
